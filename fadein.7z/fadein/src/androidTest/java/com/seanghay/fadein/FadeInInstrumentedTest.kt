package com.seanghay.fadein

import android.graphics.Bitmap
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.seanghay.fadein.encoder.SimpleFadeEncoder
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File

@RunWith(AndroidJUnit4::class)
class FadeInInstrumentedTest {

    @Test
    fun encodeTwoBitmaps_createsMp4() {
        val appContext = InstrumentationRegistry.getInstrumentation().targetContext
        val outDir = appContext.filesDir
        val output = File(outDir, "fade_test.mp4")
        if (output.exists()) output.delete()

        // Create two simple bitmaps (red and blue)
        val width = 640
        val height = 360
        val bmp1 = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        bmp1.eraseColor(0xFFFF0000.toInt()) // red

        val bmp2 = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        bmp2.eraseColor(0xFF0000FF.toInt()) // blue

        val encoder = SimpleFadeEncoder(width = width, height = height, frameRate = 30, bitrate = 2_000_000)
        encoder.encode(Pair(bmp1, bmp2), output, durationMs = 2000L)

        assertTrue("Output mp4 should exist", output.exists())
        assertTrue("Output mp4 should have non-zero length", output.length() > 0)
    }
}
