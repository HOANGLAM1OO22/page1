package com.seanghay.fadein.gles.graphics

import android.opengl.Matrix

fun mat4(elements: FloatArray) = Matrix4f(elements)
fun mat4() = Matrix4f()

data class Matrix4f(var elements: FloatArray = FloatArray(4 * 4)) :
    Iterator<Float> by elements.iterator() {

    init {
        Matrix.setIdentityM(elements, 0)
    }

    operator fun get(index: Int) = elements[index]

    operator fun set(index: Int, value: Float) {
        elements[index] = value
    }

    operator fun times(mat4: Matrix4f): Matrix4f {
        val result = Matrix4f()
        Matrix.multiplyMM(
            result.elements, 0, elements,
            0, mat4.elements, 0
        )
        return result
    }
}
