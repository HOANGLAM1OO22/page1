package com.seanghay.studio.gles.graphics.uniform

import android.opengl.GLES20

class FloatUniform(name: String) : Uniform<Float>(name) {

    override fun loadLocation(): Int {
        return GLES20.glGetUniformLocation(program, name)
    }

    override fun rationalChecks() {
        if (program == -1) throw RuntimeException("Invalid program")
        if (_location == -1 && !isOptional)
            throw RuntimeException("Uniform name: $name is not found! Did you Initialize it yet?")
    }

    override fun setValue(value: Float) {
        GLES20.glUniform1f(_location, value)
        cachedValue = value
    }

    override fun getValue(): Float {
        val args = FloatArray(1)
        GLES20.glGetUniformfv(program, _location, args, 0)
        return args[0]
    }
}

fun uniform1f(name: String) = FloatUniform(name)
