package com.seanghay.fadein.gles.egl

import android.opengl.EGL14
import android.opengl.GLES20

inline fun <T> glScope(message: String = "", block: (() -> T)): T {
    return block().also {
        var error: Int = GLES20.glGetError()
        while (error != GLES20.GL_NO_ERROR) {
            val errorMessage = error
            error = GLES20.glGetError()
            throw RuntimeException("GL Error: $message\n 0x${errorMessage.toString(16)}")
        }
    }
}

inline fun <T> eglScope(message: String = "", block: (() -> T)): T {
    return block().also {
        val error = EGL14.eglGetError()
        if (error != EGL14.EGL_SUCCESS) {
            throw RuntimeException("$message: EGL Error: 0x${error.toString(16)}")
        }
    }
}
