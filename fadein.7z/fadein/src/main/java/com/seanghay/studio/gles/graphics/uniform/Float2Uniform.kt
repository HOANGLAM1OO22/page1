package com.seanghay.studio.gles.graphics.uniform

import com.seanghay.studio.gles.graphics.Vector2f
import android.opengl.GLES20

class Float2Uniform(name: String) : Uniform<Vector2f>(name) {

    override fun loadLocation(): Int {
        return GLES20.glGetUniformLocation(program, name)
    }

    override fun rationalChecks() {
        if (program == -1) throw RuntimeException("Invalid program")
        if (_location == -1 && !isOptional)
            throw RuntimeException("Uniform name: $name is not found! Did you Initialize it yet?")
    }

    override fun setValue(value: Vector2f) {
        GLES20.glUniform2f(_location, value.x, value.y)
        cachedValue = value
    }

    override fun getValue(): Vector2f {
        return cachedValue()
    }
}
