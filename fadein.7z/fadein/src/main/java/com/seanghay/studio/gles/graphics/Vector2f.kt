package com.seanghay.studio.gles.graphics

data class Vector2f(var x: Float = 0f, var y: Float = 0f)
