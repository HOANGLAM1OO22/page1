package com.seanghay.studio.gles.graphics.uniform

import android.opengl.GLES20

class BooleanUniform(name: String) : Uniform<Boolean>(name) {

    override fun loadLocation(): Int {
        return GLES20.glGetUniformLocation(program, name)
    }

    override fun rationalChecks() {
        if (program == -1) throw RuntimeException("Invalid program")
        if (_location == -1 && !isOptional)
            throw RuntimeException("Uniform name: $name is not found! Did you Initialize it yet?")
    }

    override fun setValue(value: Boolean) {
        GLES20.glUniform1i(_location, if (value) 1 else 0)
        cachedValue = value
    }

    override fun getValue(): Boolean {
        val args = IntArray(1)
        GLES20.glGetUniformiv(program, _location, args, 0)
        return args[0] != 0
    }
}
