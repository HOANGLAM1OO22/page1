package com.seanghay.studio.gles.graphics.uniform

import com.seanghay.studio.gles.graphics.Matrix4f
import android.opengl.GLES20

class Mat4Uniform(name: String) : Uniform<Matrix4f>(name) {

    override fun loadLocation(): Int {
        return GLES20.glGetUniformLocation(program, name)
    }

    override fun rationalChecks() {
        if (program == -1) throw RuntimeException("Invalid program")
        if (_location == -1 && !isOptional)
            throw RuntimeException("Uniform name: $name is not found! Did you Initialize it yet?")
    }

    override fun setValue(value: Matrix4f) {
        GLES20.glUniformMatrix4fv(_location, 1, false, value.elements, 0)
        cachedValue = value
    }

    override fun getValue(): Matrix4f {
        // Not implemented readback
        return cachedValue()
    }
}

fun uniform1i(name: String) = com.seanghay.studio.gles.graphics.uniform.IntUniform(name)
fun uniform2f(name: String) = com.seanghay.studio.gles.graphics.uniform.Float2Uniform(name)
