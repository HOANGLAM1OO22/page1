package com.seanghay.studio.gles.graphics.uniform

import android.opengl.GLES20

class IntUniform(name: String) : Uniform<Int>(name) {

    override fun loadLocation(): Int {
        return GLES20.glGetUniformLocation(program, name)
    }

    override fun rationalChecks() {
        if (program == -1) throw RuntimeException("Invalid program")
        if (_location == -1 && !isOptional)
            throw RuntimeException("Uniform name: $name is not found! Did you Initialize it yet?")
    }

    override fun setValue(value: Int) {
        GLES20.glUniform1i(_location, value)
        cachedValue = value
    }

    override fun getValue(): Int {
        val args = IntArray(1)
        GLES20.glGetUniformiv(program, _location, args, 0)
        return args[0]
    }
}
