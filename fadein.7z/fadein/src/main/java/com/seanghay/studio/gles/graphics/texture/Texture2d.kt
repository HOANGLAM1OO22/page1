package com.seanghay.fadein.gles.graphics.texture

open class Texture2d : Texture() {
    // placeholder for any 2d-specific behavior
}
