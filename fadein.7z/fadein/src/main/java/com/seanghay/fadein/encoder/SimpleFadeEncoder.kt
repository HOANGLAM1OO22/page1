package com.seanghay.fadein.encoder

import android.graphics.Bitmap
import android.media.MediaCodec
import android.media.MediaCodec.BufferInfo
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.opengl.GLES20
import android.opengl.GLUtils
import com.seanghay.fadein.gles.egl.EglCore
import com.seanghay.fadein.gles.egl.EglSurfaceBase
import com.seanghay.fadein.utils.GlUtils
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

/**
 * Minimal encoder that renders two Bitmaps into an H264 MP4 using a simple alpha blend (fade).
 * This implementation is fully contained inside the fadein module and does not reference the
 * external `studio` module.
 */
class SimpleFadeEncoder(
  private val width: Int,
  private val height: Int,
  private val frameRate: Int = 30,
  private val bitrate: Int = 4_000_000
) {

  private val mimeType = "video/avc"

  private var encoder: MediaCodec? = null
  private var muxer: MediaMuxer? = null
  private var trackIndex = -1
  private var isMuxerStarted = false

  private val vertexCoords = floatArrayOf(
    -1f, -1f, 0f,
    1f, -1f, 0f,
    -1f, 1f, 0f,
    1f, 1f, 0f
  )

  private val texCoords = floatArrayOf(
    0f, 1f,
    1f, 1f,
    0f, 0f,
    1f, 0f
  )

  private val vertexBuffer: FloatBuffer = ByteBuffer.allocateDirect(vertexCoords.size * 4)
    .order(ByteOrder.nativeOrder()).asFloatBuffer().apply { put(vertexCoords).position(0) }

  private val texBuffer: FloatBuffer = ByteBuffer.allocateDirect(texCoords.size * 4)
    .order(ByteOrder.nativeOrder()).asFloatBuffer().apply { put(texCoords).position(0) }

  // Simple textured quad shader with uniform alpha
  private val vertexShader = """
    attribute vec4 aPosition;
    attribute vec2 aTexCoord;
    varying vec2 vTexCoord;
    void main() {
      gl_Position = aPosition;
      vTexCoord = aTexCoord;
    }
  """.trimIndent()

  private val fragmentShader = """
    precision mediump float;
    uniform sampler2D uTexture;
    uniform float uAlpha;
    varying vec2 vTexCoord;
    void main() {
      vec4 c = texture2D(uTexture, vTexCoord);
      gl_FragColor = vec4(c.rgb, c.a * uAlpha);
    }
  """.trimIndent()

  fun encode(bitmaps: Pair<Bitmap, Bitmap>, output: File, durationMs: Long) {
    val frameCount = (durationMs * frameRate / 1000L).toInt().coerceAtLeast(1)

    // Configure encoder and muxer
    val format = MediaFormat.createVideoFormat(mimeType, width, height)
    format.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
    format.setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
    format.setInteger(MediaFormat.KEY_FRAME_RATE, frameRate)
    format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)

    encoder = MediaCodec.createEncoderByType(mimeType).apply {
      configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
      val inputSurface = createInputSurface()
      start()

      // Prepare EGL to render onto encoder input surface
      val eglCore = EglCore(EglCore.FLAG_RECORDABLE)
      eglCore.setup()
      val eglSurface = EglSurfaceBase(eglCore)
      eglSurface.createWindowSurface(inputSurface)
      eglSurface.makeCurrent()

      // Create GL program
      val shaderData = GlUtils.createProgramWithShaders(vertexShader, fragmentShader)
      val prog = shaderData.program
      GLES20.glUseProgram(prog)

      val aPosition = GLES20.glGetAttribLocation(prog, "aPosition")
      val aTexCoord = GLES20.glGetAttribLocation(prog, "aTexCoord")
      val uTexture = GLES20.glGetUniformLocation(prog, "uTexture")
      val uAlpha = GLES20.glGetUniformLocation(prog, "uAlpha")

      // Upload textures
      val textures = IntArray(2)
      GLES20.glGenTextures(2, textures, 0)
      setupTexture(textures[0], bitmaps.first)
      setupTexture(textures[1], bitmaps.second)

      // Create muxer
      muxer = MediaMuxer(output.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
      isMuxerStarted = false
      trackIndex = -1

      // Buffer info
      val bufferInfo = BufferInfo()

      // Frame loop
      for (i in 0 until frameCount) {
        val progress = i.toFloat() / (frameCount - 1).coerceAtLeast(1)

        // Draw bottom texture (fully opaque)
        GLES20.glViewport(0, 0, width, height)
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)

        // Draw bottom image (texture 0) with alpha 1.0
        drawTexture(prog, aPosition, aTexCoord, uTexture, uAlpha, textures[0], 1f)

        // Draw top image (texture 1) with alpha = progress
        drawTexture(prog, aPosition, aTexCoord, uTexture, uAlpha, textures[1], progress)

        // Set presentation time and swap
        val pts = computePresentationTimeNsec(i.toLong())
        eglSurface.setPresentationTime(pts)
        eglSurface.swapBuffers()

        // Drain encoder output
        drainEncoder(this, bufferInfo)
      }

      // Signal end of stream
      this.signalEndOfInputStream()
      drainEncoder(this, bufferInfo, true)

      // Cleanup
      eglSurface.releaseEglSurface()
      eglCore.release()
      GLES20.glDeleteTextures(2, textures, 0)

      stop()
      release()
    }

    // muxer may be null if encoding failed
    muxer?.stop()
    muxer?.release()
  }

  private fun setupTexture(textureId: Int, bitmap: Bitmap) {
    GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureId)
    GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
    GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
    GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
    GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
    GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bitmap, 0)
    GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, 0)
  }

  private fun drawTexture(
    program: Int,
    aPosition: Int,
    aTexCoord: Int,
    uTexture: Int,
    uAlpha: Int,
    textureId: Int,
    alpha: Float
  ) {
    GLES20.glUseProgram(program)

    vertexBuffer.position(0)
    GLES20.glEnableVertexAttribArray(aPosition)
    GLES20.glVertexAttribPointer(aPosition, 3, GLES20.GL_FLOAT, false, 3 * 4, vertexBuffer)

    texBuffer.position(0)
    GLES20.glEnableVertexAttribArray(aTexCoord)
    GLES20.glVertexAttribPointer(aTexCoord, 2, GLES20.GL_FLOAT, false, 2 * 4, texBuffer)

    GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
    GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureId)
    GLES20.glUniform1i(uTexture, 0)
    GLES20.glUniform1f(uAlpha, alpha)

    GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)

    GLES20.glDisableVertexAttribArray(aPosition)
    GLES20.glDisableVertexAttribArray(aTexCoord)
    GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, 0)
  }

  private fun computePresentationTimeNsec(frameIndex: Long): Long {
    val ONE_BILLION = 1_000_000_000L
    return frameIndex * ONE_BILLION / frameRate
  }

  private fun drainEncoder(codec: MediaCodec, bufferInfo: BufferInfo, endOfStream: Boolean = false) {
    if (endOfStream) codec.signalEndOfInputStream()

    val timeoutUs = 10000L
    while (true) {
      val encoderStatus = codec.dequeueOutputBuffer(bufferInfo, timeoutUs)
      when (encoderStatus) {
        MediaCodec.INFO_TRY_AGAIN_LATER -> if (!endOfStream) return
        MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
          if (isMuxerStarted) throw RuntimeException("format changed twice")
          val newFormat = codec.outputFormat
          muxer = muxer ?: throw RuntimeException("Muxer not initialized")
          trackIndex = muxer!!.addTrack(newFormat)
          muxer!!.start()
          isMuxerStarted = true
        }
        else -> if (encoderStatus >= 0) {
          val encodedData = codec.getOutputBuffer(encoderStatus) ?: continue
          if (bufferInfo.size != 0) {
            encodedData.position(bufferInfo.offset)
            encodedData.limit(bufferInfo.offset + bufferInfo.size)
            if (!isMuxerStarted) throw RuntimeException("muxer hasn't started")
            muxer!!.writeSampleData(trackIndex, encodedData, bufferInfo)
          }
          codec.releaseOutputBuffer(encoderStatus, false)
          if (bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
            return
          }
        }
      }
    }
  }
}
